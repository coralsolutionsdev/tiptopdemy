$(document).ready(function(){
	$('[data-toggle="slide-bar-close"]').click(function(){
		$('slide-bar').toggleClass('slide-bar-off');
	});
});