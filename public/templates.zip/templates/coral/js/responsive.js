$(document).ready(function(){
	$(".mobile a").click(function(){
		$(".side-bar").slideToggle("fast");
	});
});